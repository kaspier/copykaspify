// script.js

// --- HISTORY MANAGEMENT & SCREEN SWITCHING ---
// State management for seamless back gesture on iOS Safari, Android, and desktop browsers

let isNavigatingBack = false;

// Initialize history state on load
window.addEventListener('load', () => {
    history.replaceState({ screen: 'main-view' }, '', '');
    initSwipeBack();
});

// Handle popstate event (triggered by iPhone edge swipe, Android back gesture, browser back button)
window.addEventListener('popstate', (event) => {
    isNavigatingBack = true;
    const targetScreen = (event.state && event.state.screen) ? event.state.screen : 'main-view';
    
    // Hide modal dialogs if open
    const confirmModal = document.getElementById("confirm-modal");
    const transferConfirmModal = document.getElementById("transfer-confirm-modal");
    if (confirmModal) confirmModal.style.display = "none";
    if (transferConfirmModal) transferConfirmModal.style.display = "none";

    // Hide all full screens
    const screens = ["payment-screen", "success-screen", "transfer-screen", "transfer-success-screen", "receipt-screen"];
    screens.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
    });

    const mainView = document.getElementById("main-view");

    if (targetScreen === 'main-view') {
        if (mainView) mainView.style.display = "block";
    } else {
        const targetEl = document.getElementById(targetScreen);
        if (targetEl) {
            if (targetScreen === 'payment-screen' || targetScreen === 'transfer-screen' || targetScreen.includes('modal')) {
                targetEl.style.display = 'flex';
            } else {
                targetEl.style.display = 'block';
            }
        } else if (mainView) {
            mainView.style.display = "block";
        }
    }
    isNavigatingBack = false;
});

function navigateToScreen(screenId) {
    if (!isNavigatingBack) {
        history.pushState({ screen: screenId }, '', '#' + screenId);
    }
}

function changeBalance() {
    let current = document.getElementById("balance").innerText.replace(" ₸", "").replace(/\s/g, '');
    let newSum = prompt("Введите сумму баланса:", current);
    if (newSum) {
        document.getElementById("balance").innerText = parseFloat(newSum).toLocaleString('ru-RU', { minimumFractionDigits: 2 }) + " ₸";
    }
}

function openPayment() {
    document.getElementById("payment-screen").style.display = "flex";
    document.getElementById("main-view").style.display = "none";
    navigateToScreen("payment-screen");
}

function closePayment() {
    if (history.state && history.state.screen === "payment-screen") {
        history.back();
    } else {
        document.getElementById("payment-screen").style.display = "none";
        document.getElementById("main-view").style.display = "block";
        closeConfirmModal();
    }
}

function changePaymentSum() {
    let current = document.getElementById("edit-amount").innerText.replace(" Т", "").replace(/\s/g, '');
    let newSum = prompt("Введите сумму платежа:", current);
    if (newSum) {
        let formatted = parseFloat(newSum).toLocaleString('ru-RU');
        document.getElementById("edit-amount").innerText = formatted + " ₸";
    }
}

function openConfirmModal() {
    const vendor = document.getElementById("edit-vendor").value;
    const amount = document.getElementById("edit-amount").innerText;

    document.getElementById("modal-vendor-name").innerText = vendor;
    document.getElementById("modal-amount-val").innerText = amount;
    document.getElementById("modal-final-sum").innerText = amount;
    document.getElementById("final-btn-text").innerText = "Оплатить " + amount;

    document.getElementById("confirm-modal").style.display = "flex";
    navigateToScreen("confirm-modal");
}

function closeConfirmModal() {
    if (history.state && history.state.screen === "confirm-modal") {
        history.back();
    } else {
        document.getElementById("confirm-modal").style.display = "none";
    }
}

function completePayment() {
    const vendor = document.getElementById("modal-vendor-name").innerText;
    const amount = document.getElementById("modal-final-sum").innerText;

    document.getElementById("success-vendor").innerText = vendor;
    document.getElementById("success-amount").innerText = amount;

    const now = new Date();
    const formattedDate = now.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) 
    + ", " + now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

    document.getElementById("success-date").innerText = formattedDate;

    document.getElementById("confirm-modal").style.display = "none";
    document.getElementById("payment-screen").style.display = "none";
    document.getElementById("success-screen").style.display = "block";
    updateReceipt();
    
    navigateToScreen("success-screen");
}

function goHome() {
    if (history.state && history.state.screen !== "main-view") {
        history.pushState({ screen: 'main-view' }, '', ' ');
    }
    document.getElementById("success-screen").style.display = "none";
    document.getElementById("main-view").style.display = "block";
}

function openTransferScreen() {
    document.getElementById("transfer-screen").style.display = "flex";
    document.getElementById("main-view").style.display = "none";
    document.getElementById("transfer-sender-balance").innerText = document.getElementById("balance").innerText;
    navigateToScreen("transfer-screen");
}

function closeTransferScreen() {
    if (history.state && history.state.screen === "transfer-screen") {
        history.back();
    } else {
        document.getElementById("transfer-screen").style.display = "none";
        document.getElementById("main-view").style.display = "block";
    }
}

// Обновление кнопки перевода при изменении суммы
const transferAmountInput = document.getElementById('transfer-amount-input');
if (transferAmountInput) {
    transferAmountInput.addEventListener('input', function() {
        let val = this.value.replace(/[^0-9]/g, '');
        let num = parseInt(val) || 0;
        let formatted = num.toLocaleString('ru-RU');
        this.value = formatted + ' ₸';
        document.getElementById('btnTransfer').innerText = `Перевести ${this.value}`;
    });
}

function openTransferConfirmModal() {
    const recipient = document.getElementById("recipient-name").value;
    const amount = document.getElementById('transfer-amount-input').value;

    document.getElementById("transfer-modal-recipient-name").innerText = recipient;
    document.getElementById("transfer-modal-amount-val").innerText = amount;
    document.getElementById("transfer-modal-final-sum").innerText = amount;
    document.getElementById("transfer-final-btn-text").innerText = "Перевести " + amount;

    document.getElementById("transfer-confirm-modal").style.display = "flex";
    navigateToScreen("transfer-confirm-modal");
}

function closeTransferConfirmModal() {
    if (history.state && history.state.screen === "transfer-confirm-modal") {
        history.back();
    } else {
        document.getElementById("transfer-confirm-modal").style.display = "none";
    }
}

function completeTransfer() {
    const recipient = document.getElementById("transfer-modal-recipient-name").innerText;
    const amount = document.getElementById("transfer-modal-final-sum").innerText;

    document.getElementById("transfer-success-recipient-save").innerText = recipient;
    document.getElementById("transfer-success-amount").innerText = amount;

    document.getElementById("transfer-confirm-modal").style.display = "none";
    document.getElementById("transfer-screen").style.display = "none";
    document.getElementById("transfer-success-screen").style.display = "block";
    navigateToScreen("transfer-success-screen");
}

function goHomeFromTransfer() {
    if (history.state && history.state.screen === "transfer-success-screen") {
        history.back();
    } else {
        document.getElementById("transfer-success-screen").style.display = "none";
        document.getElementById("transfer-screen").style.display = "flex";
    }
}

function showReceipt() {
    document.getElementById("success-screen").style.display = "none";
    document.getElementById("transfer-success-screen").style.display = "none";
    updateReceipt();
    document.getElementById("receipt-screen").style.display = "block";
    navigateToScreen("receipt-screen");
}

function closeReceipt() {
    if (history.state && history.state.screen === "receipt-screen") {
        history.back();
    } else {
        document.getElementById("receipt-screen").style.display = "none";
        document.getElementById("main-view").style.display = "block";
    }
}

function generateRandomNumber(length) {
    let result = '';
    for (let i = 0; i < length; i++) {
        result += Math.floor(Math.random() * 10);
    }
    return result;
}

function updateReceipt() {
    const amount = document.getElementById("success-amount").innerText;
    const now = new Date();
    const dateStr = now.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '.');
    const timeStr = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

    document.getElementById("receipt-vendor-name").innerText = document.getElementById("edit-school-name").value;
    document.getElementById("receipt-ip").innerText = document.getElementById("edit-ip").value;
    document.getElementById("receipt-amount").innerText = amount;
    document.getElementById("receipt-item-name").innerText = document.getElementById("edit-item-name").value;
    document.getElementById("receipt-item-quantity").innerText = `1 шт. x ${amount.replace(' ₸', '')} ₸`;
    document.getElementById("receipt-item-price").innerText = `${amount.replace(' ₸', '')} ₸`;
    document.getElementById("receipt-check-no").innerText = 'QR' + generateRandomNumber(10);
    document.getElementById("receipt-date").innerText = `${dateStr} ${timeStr}`;
    document.getElementById("receipt-address").innerText = document.getElementById("edit-address").value;
    document.getElementById("receipt-iin").innerText = document.getElementById("edit-iin").value;
    document.getElementById("receipt-fio").innerText = document.getElementById("edit-fio").value;
    document.getElementById("receipt-rnm").innerText = '01' + generateRandomNumber(11);
    document.getElementById("receipt-znm").innerText = 'KK' + generateRandomNumber(9);
    document.getElementById("receipt-fp").innerText = generateRandomNumber(12);
    document.getElementById("receipt-ofd").innerText = document.getElementById("edit-ofd").value;
}

// Tab switching logic
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        tabContents.forEach(content => content.style.display = 'none');
        const contentEl = document.getElementById(tab.id.replace('-btn', ''));
        if (contentEl) contentEl.style.display = 'block';
    });
});

// --- SWIPE BACK GESTURE LOGIC FOR IPHONE ---
function initSwipeBack() {
    let startX = 0;
    let startY = 0;
    let currentX = 0;
    let isSwiping = false;

    const fullScreens = ["payment-screen", "transfer-screen", "success-screen", "transfer-success-screen", "receipt-screen"];

    document.addEventListener('touchstart', (e) => {
        const touch = e.touches[0];
        startX = touch.clientX;
        startY = touch.clientY;
        currentX = startX;

        // Check if any sub-screen is active
        const activeScreen = fullScreens.find(id => {
            const el = document.getElementById(id);
            return el && (el.style.display === "flex" || el.style.display === "block");
        });

        // Trigger swipe if touch starts near left edge (within 80px)
        if (activeScreen && startX < 80) {
            isSwiping = true;
        } else {
            isSwiping = false;
        }
    }, { passive: true });

    document.addEventListener('touchmove', (e) => {
        if (!isSwiping) return;
        const touch = e.touches[0];
        currentX = touch.clientX;
    }, { passive: true });

    document.addEventListener('touchend', (e) => {
        if (!isSwiping) return;
        const diffX = currentX - startX;
        const diffY = Math.abs(e.changedTouches[0].clientY - startY);

        // If swiped right more than 60px with horizontal movement
        if (diffX > 60 && diffY < diffX) {
            history.back();
        }
        isSwiping = false;
    });

    // Close modals on clicking backdrop background
    ['confirm-modal', 'transfer-confirm-modal'].forEach(modalId => {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    if (modalId === 'confirm-modal') closeConfirmModal();
                    if (modalId === 'transfer-confirm-modal') closeTransferConfirmModal();
                }
            });
        }
    });
}